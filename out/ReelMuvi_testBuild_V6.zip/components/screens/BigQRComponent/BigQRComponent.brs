sub init()
  m.titleLabel = m.top.findNode("titleLabel")
  m.titleLabel.color = getTextColor()
  m.titleLabel.font.size = 54
  m.titleLabel.text = getText("almost_there")

  labels = {
    "label1": "1. " + getText("scan_qr_code"),
    "label2": "2. " + getText("complete_payment"),
    "label3": "3. " + getText("tap_below_to_refresh")
  }

  for each id in labels
    node = m.top.findNode(id)
    node.color = getTextColor()
    if node <> invalid
      node.text = labels[id]
      node.font.size = 26
    end if
  end for

  m.qrPoster = m.top.findNode("qrPoster")
  m.qrPoster.uri = m.top.qrUrl

  m.closeLabelList = m.top.findNode("closeLabelList")
  m.closeLabelList.observeField("itemSelected", "onItemSelected")
  m.closeLabelList.focusBitmapBlendColor = getButtonSelectionColor()
  m.closeLabelList.focusFootprintBlendColor = getButtonSelectionColor()
  m.closeLabelList.color = getTextColor()
  m.closeLabelList.focusedColor = "#FFFFFF"
end sub

sub onSetButtonsArray()
  ' This function can be called to update the buttons dynamically if needed
  content = CreateObject("roSGNode", "ContentNode")

  if m.top.buttonsArray <> invalid and m.top.buttonsArray.count() > 0
    for each button in m.top.buttonsArray
      item = content.createChild("ContentNode")
      item.title = button
    end for
  end if

  m.closeLabelList.content = content
  m.closeLabelList.setFocus(true)
end sub

sub onItemSelected()
  selectedIndex = m.closeLabelList.itemSelected
  if selectedIndex = 0 ' Refresh
    m.top.refreshRequested = true
  else if selectedIndex = 1 ' Cancel
    m.top.closeQROverlay = true
  end if

  m.top.closeLabelListSelectedItem = m.closeLabelList["content"].getChild(selectedIndex).title  ' Clear the title of the selected item to prevent it from showing as focused
end sub

' Inline helper for localization
function getText(key as string) as string
  strings = getStrings()

  if m.global.language_keywords <> invalid and m.global.language_keywords[key] <> invalid and m.global.language_keywords[key][getLanguageCodeSelected()] <> invalid
    return m.global.language_keywords[key][getLanguageCodeSelected()]
  end if

  if strings <> invalid and strings[key] <> invalid
    return strings[key]
  end if

  return "" ' safe fallback
end function