sub init()
    m.top.functionName = "start"
end sub

function runHomeListApiTask(homeType as string)
    m.homeType = homeType
    ?"sdjkasjgds5454"
    ?m.homeType 
    m.top.control = "RUN"
end function

function stopHomeListApiTask(param as string)
    m.top.control = "STOP"
end function

sub start()
    responseDataHomeListApiTaskList = callHomeListApiTaskApi(m.homeType)
    ' checking if response is not invalid. If it is not invalid,  then saves the response
    if responseDataHomeListApiTaskList <> invalid and responseDataHomeListApiTaskList.data <> invalid and responseDataHomeListApiTaskList.data.data <> invalid then
        HomeListApiTaskList = parseHomeListApiContent(responseDataHomeListApiTaskList.data.data)
        m.top.HomeListApiTaskContent = HomeListApiTaskList
        m.top.HomeListApiTaskListStatus = true
    else
        m.top.HomeListApiTaskContent = invalid
        m.top.HomeListApiTaskListStatus = false
    end if
end sub